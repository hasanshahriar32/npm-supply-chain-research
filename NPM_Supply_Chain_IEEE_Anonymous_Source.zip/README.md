# Anonymous conference typesetting source

Open main.tex in Overleaf or run `bash compile.sh` with a LaTeX compiler.
The paper uses IEEEtran conference mode, A4 paper, and standard 10-point text.
This bundle contains the PDF and typesetting inputs, not the underlying data.
It omits author-side research notes and repository/environment provenance.
Named author configuration, author records, and the named draft are excluded.

The authors must review the scientific claims and the venue's submission
requirements before submitting this draft.
