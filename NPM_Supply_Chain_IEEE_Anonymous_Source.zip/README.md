# Anonymous conference typesetting source

Open main.tex in Overleaf or run `bash compile.sh` with a LaTeX compiler.
The paper uses IEEEtran conference mode, A4 paper, and standard 10-point text.
This bundle contains the PDF and typesetting inputs, not the underlying data.
It omits author-side research notes and repository/environment provenance.
Named author configuration, author records, and the named draft are excluded.

The LLM acknowledgment describes the actual assistance used. The venue's
restriction to non-intellectual use remains unresolved; the disclosure and
all scientific claims require human-author review before submission.
