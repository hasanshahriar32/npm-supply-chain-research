# npm structural-prioritization research artifact

Version: research-validation-2026-10-28. This prerelease contains completed computational experiments and provisional automated audit evidence. Independent human endpoint annotations remain pending. It is not a published manuscript or an assertion that the paper has been approved or accepted.

Download the attached npm-research-validation-2026-10-28-companion.zip asset. The original 27 MB database is linked at its fixed base commit instead of duplicated in this asset. The automatically generated GitHub source-code ZIP follows the base repository tag and is not the standalone executed artifact.

## Reproduce offline

Use Python 3.10 or newer. The executed environment is recorded in ENVIRONMENT.json. The numerical verification path uses the standard library; installing manuscript_q1/requirements-revision.txt also enables YAML extraction and figure rendering.

```sh
python3 download_original_input.py
python3 scripts/reproduce_journal_validation.py --recompute-cohort
```

This verifies release checksums, independently rebuilds all 12,217 original account masks, checks 228 ablation rows, recomputes the restricted exact optima underlying 288 comparisons, checks the 120 fresh-cohort metric rows, and recomputes the fresh cohort in an isolated temporary workspace with live network acquisition disabled. Timing and generation timestamps are not expected to reproduce byte-for-byte.

The original archive is preserved unchanged. Public registry identifiers are retained for replication; they are not anonymized or evidence of misconduct, present-day insecurity, independent credentials, or historical publishing rights. Source counts and hypothetical hardening outcomes are structural quantities, not incident probabilities or deployed prevention measurements.

The exact acquisition collector is preserved under manuscript_q1/protocols/executed_scripts/ and in release-base commit 43c039bebe7c36b07a5aeb50b1c8a412ad058e0f. Its hash matches the acquisition manifest. The current collector adds an offline-network guard after acquisition; online collection logic is unchanged.

## Inputs and provenance

- data/npm_ecosystem.db.zip: original retained database archive.
- manuscript_q1/protocols/: protocol and probability samples frozen before the new acquisition.
- results/revision_validation/heuristic/: full/candidate-cap/component/tie experiments and exact-instance records.
- results/revision_validation/replication/: newly retrieved root/dependency/registry observations, pinned workflow-directory metadata, graph, incidence and comparisons.
- results/revision_validation/endpoint_audit/: registry metadata and derived static evidence candidates; GitHub metadata includes the observed commits/directories.
- results/revision_validation/endpoint_transport/: provisional diagnostics using machine evidence, not human-validated conclusions.

The paths abbreviated as results/ above are under manuscript_q1/. The original 100-identifier prospective outcome cohort is a different study and is not relabeled by this artifact.

Raw third-party workflow/manifest/lockfile bodies are not redistributed in this asset. The derived evidence records retain pinned source paths, commits, hashes and concise installation/dependency evidence so those sources can be inspected at their original repositories. Offline numeric reproduction uses the released derived observations; it does not claim to redo independent human annotation or to certify the source-body evidence. Complete raw-source checks were performed in the working repository and are separately identified in its verification report.

## Source attribution

The observations originate from the npm registry, the deps.dev API, and public GitHub repository metadata/source. Original identifiers, observation URLs and timestamps are retained where relevant. Existing third-party terms and authorship are not altered by this release. No blanket license for third-party source code is asserted. See https://docs.deps.dev/api/v3/ for API semantics and source data information.

## Study limits

The 100 new roots are sampled from the original ordinary-name frame rather than all npm. The acquisition yields 94 dependency graphs and 66 eligible workflow-associated repository endpoints, with recorded failures. The 120-endpoint audit has machine evidence and pending human review. Exact benchmarks are restricted to 20 eligible candidates and never establish the full-graph optimum. Changing H denominators requires within-population interpretation. Null and unfavorable results are retained.

Original input: https://raw.githubusercontent.com/hasanshahriar32/npm-supply-chain-research/43c039bebe7c36b07a5aeb50b1c8a412ad058e0f/data/npm_ecosystem.db.zip

The download helper is the only network preparation step. It verifies SHA-256 before offline reproduction. The complete original archive also remains directly available in the versioned public repository.
