"""Download the immutable original input, verify its hash, then reproduce offline."""
import hashlib
from pathlib import Path
import urllib.request
p=Path(__file__).parent/'data/npm_ecosystem.db.zip'
p.parent.mkdir(exist_ok=True)
expected='ab45439cf94cf43f3133b0aaff644557d55e86e99430a0a7937bfd0ce5266315'
if not p.exists():
    with urllib.request.urlopen('https://raw.githubusercontent.com/hasanshahriar32/npm-supply-chain-research/43c039bebe7c36b07a5aeb50b1c8a412ad058e0f/data/npm_ecosystem.db.zip',timeout=60) as response,p.open('wb') as stream:
        while block:=response.read(1048576):stream.write(block)
assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,'Input archive checksum mismatch'
print('Original input verified; run python3 scripts/reproduce_journal_validation.py --recompute-cohort')
