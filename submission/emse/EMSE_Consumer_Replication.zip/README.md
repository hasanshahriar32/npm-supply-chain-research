# Replication companion for the paired YunoHost consumer comparison

From the extracted directory, run with Python 3.10 or newer:

    python scripts/replay_yunohost_consumer_results.py
    python scripts/verify_yunohost_empty_pnpm_roots.py
    python scripts/study_yunohost_empty_declared_roots.py verify
    python scripts/check_yunohost_bun_direct.py verify
    python scripts/check_yunohost_npm_unresolved.py verify

The command starts from retained dependency paths and registry observations.
It recomputes exact-version joins, project classifications, and the paired
bounds before and after the Yarn Classic follow-up. It checks the primary
comparison, both cutoff alternatives, and the identical-portfolio control
against every retained project row and the manuscript table.
The second command reproduces the post hoc pnpm sensitivity from the
root declaration counts in the companion. The third checks the combined
empty-root analysis. The fourth recomputes the Bun direct joins. The last
checks the npm evidence and the final bounds. Pinned hashes identify the
source files checked for these records.

The included registry projection keeps exact package and version keys, receipt
status, SHA-512 tokens and membership in the frozen portfolios as numeric
indices. Yarn rows also retain the dependency declarations and flags used by
the path verifier. The extraction outputs preserve completeness decisions
under the frozen rules. Re-extracting from the original package files or
verifying the original HTTP receipts requires the acquisition inputs.

The pinned source links, corroborated positive paths and checked location
counts for the five confirmed primary differences are in:

    research/consumer_holdout/runs/yunohost-yarn-classic/confirmed_cases.md

The archive covers the 215-project comparison and the follow-up analyses
reported in the manuscript table.
