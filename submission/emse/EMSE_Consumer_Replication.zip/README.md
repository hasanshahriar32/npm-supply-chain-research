# Replication companion for the paired YunoHost consumer comparison

From the extracted directory, run with Python 3.10 or newer:

    python scripts/replay_yunohost_consumer_results.py
    python scripts/verify_yunohost_empty_pnpm_roots.py

The command starts from retained dependency paths and registry observations.
It recomputes exact-version joins, project classifications, and the paired
bounds before and after the Yarn Classic follow-up. It checks the primary
comparison, both cutoff alternatives, and the identical-portfolio control
against every retained project row and the manuscript table.
The second command reproduces the post hoc pnpm sensitivity from the
root declaration counts in the companion. Pinned hashes identify the
source files checked for those counts.

The included registry projection keeps exact package and version keys, receipt
status, SHA-512 tokens and membership in the frozen portfolios as numeric
indices. Yarn rows also retain the dependency declarations and flags used by
the path verifier. The extraction outputs preserve completeness decisions
under the frozen rules. Re-extracting from the original package files or
verifying the original HTTP receipts requires the acquisition inputs.

The pinned source links, corroborated positive paths and checked location
counts for the five confirmed primary differences are in:

    research/consumer_holdout/runs/yunohost-yarn-classic/confirmed_cases.md

The archive covers the 215-project comparison and its Yarn Classic follow-up.
