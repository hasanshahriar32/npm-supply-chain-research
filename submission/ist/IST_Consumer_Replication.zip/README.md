# Replication companion for the paired consumer comparisons

From the extracted directory, run with Python 3.10 or newer:

    python scripts/replay_yunohost_consumer_results.py
    python scripts/verify_yunohost_empty_pnpm_roots.py
    python scripts/study_yunohost_empty_declared_roots.py verify
    python scripts/check_yunohost_bun_direct.py verify
    python scripts/check_yunohost_npm_unresolved.py verify
    python scripts/replay_yunohost_budgets.py
    python scripts/replay_selfhosted_comparison.py
    python scripts/study_selfhosted_lockfile_followup.py verify
    python scripts/study_selfhosted_registry_extension.py verify
    python scripts/study_selfhosted_yarn_evidence.py verify
    python scripts/check_consumer_pair_support.py verify
    python scripts/check_selfhosted_modern_yarn_roots.py verify

The command starts from retained dependency paths and registry observations.
It recomputes exact-version joins, project classifications, and the paired
bounds before and after the Yarn Classic follow-up. It checks the primary
comparison, both cutoff alternatives, and the identical-portfolio control
against every retained project row and the manuscript table.
The second command reproduces the post hoc pnpm sensitivity from the
root declaration counts in the companion. The third checks the combined
empty-root analysis. The fourth recomputes the Bun direct joins, and the
fifth checks the npm evidence and the combined five-account bounds.
The sixth verifies both the paired summary and the exploratory budget
check from a wider projection of the retained registry memberships.
The seventh verifies all four frozen Awesome-Selfhosted comparisons
and recomputes its empty-root sensitivity and six-budget comparison.
The next three validate the npm and pnpm follow-ups and the Yarn Classic
follow-up from the retained paths and dated observations. The last two
recount the pairs by root evidence and verify the modern Yarn empty roots.
Pinned hashes identify the source files checked for these records.

The included registry projection keeps exact package and version keys, receipt
status, SHA-512 tokens and membership in the frozen portfolios as numeric
indices. Yarn rows also retain the dependency declarations and flags used by
the path verifier. The extraction outputs preserve completeness decisions
under the frozen rules. Re-extracting from the original package files or
verifying the original HTTP receipts requires the acquisition inputs.

The pinned source links, corroborated positive paths and checked location
counts for the five confirmed primary differences are in:

    research/consumer_holdout/runs/yunohost-yarn-classic/confirmed_cases.md

The archive covers both the 215-project YunoHost and 155-project
Awesome-Selfhosted comparisons and their reported follow-ups.
